<!-- @file Overview of the theme registry workflow in Drupal Bootstrap. -->
<!-- @defgroup registry -->
# Theme Registry

{.alert.alert-warning} @todo Needs documentation.
